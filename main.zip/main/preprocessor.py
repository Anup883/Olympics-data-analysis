import pandas as pd


def load_data(df, region_df):
    # Filter for Summer Olympics only
    df = df[df['Season'] == 'Summer']

    # Merge region information
    df = df.merge(region_df[['NOC', 'region']], on='NOC', how='left')

    # Drop duplicates
    df.drop_duplicates(inplace=True)

    # One-hot encode medals
    df = pd.concat([df, pd.get_dummies(df['Medal'])], axis=1)

    return df
